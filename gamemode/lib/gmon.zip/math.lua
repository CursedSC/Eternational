function math.ISRU(x, a)
    return x / math.sqrt(1 + a * x * x)
end

function math.SmoothStep(value)
    local t = math.Clamp(value, 0, 1)

    return t * t * (3 - 2 * t)
end

function math.SmoothStep2(value, curvature)
    value = math.Clamp(value, 0, 1)
    curvature = math.Clamp(curvature, -1, 1)

    if curvature == -1 then
        if value == 0 or value == 1 then
            return value
        else
            return 0.5
        end
    elseif curvature == 0 then
        return value
    elseif curvature == 1 then
        if value == 1 then
            if value <= 0.5 then
                return 0
            else
                return 1
            end
        end
    end

    if curvature < 0 then
        curvature = math.Lerp(-curvature, 0, -math.pi / 4)
    else
        curvature = math.Lerp(curvature, 0, math.pi / 2)
    end

    curvature = math.tan(curvature)

    return math.ISRU(2 * value - 1, curvature) / math.ISRU(1, curvature) / 2 + 0.5
end

function math.HalfSmoothStepStart(value)
    local transformedValue = value / 2

    return 2 * (3 * transformedValue ^ 2 - 2 * transformedValue ^ 3)
end

function math.HalfSmoothStepEnd(value)
    local transformedValue = value / 2 + 0.5

    return 2 * (3 * transformedValue ^ 2 - 2 * transformedValue ^ 3) - 1
end

function math.ReverseSmoothStep(value)
    return ((2 * value - 1) ^ 3 + 1) / 2
end

function math.SmoothStepStart(value, curvature)
    return 2 * math.SmoothStep2(math.Lerp(value, 0, 0.5), curvature)
end

function math.SmoothStepEnd(value, curvature)
    return 2 * math.SmoothStep2(math.Lerp(value, 0.5, 1), curvature) - 1
end

function math.RegenerateSeed()
    math.randomseed(os.time() + os.clock())
end

function math.Sign(number)
    if TypeID(number) ~= TYPE_NUMBER then
        return 0
    end

    return number > 0 and 1 or number < 0 and -1 or 0
end