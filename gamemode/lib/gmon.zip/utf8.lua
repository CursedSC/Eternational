local function pack(...)
    return { ... }
end

function utf8.sub(string, startPosition, endPosition)
    return utf8.char(unpack(table.Slice(pack(utf8.codepoint(string, 1, -1)), startPosition, endPosition)))
end