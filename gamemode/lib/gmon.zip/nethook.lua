if SERVER then
    util.AddNetworkString("nethook.call")
end

local hooks = { }

nethook = { }

function nethook.Start(name)
    net.Start("nethook.call")
    net.WriteUInt(crc32.Hash(name), 32)
end

nethook.Send = net.Send
nethook.Broadcast = net.Broadcast

nethook.SendToServer = net.SendToServer

function nethook.Hook(name, callback)
    hooks[crc32.Hash(name)] = callback
end

function nethook.GetHooks()
    return hooks
end

net.Receive("nethook.call", function(length, ...)
    local hookName = net.ReadUInt(32)

    if TypeID(hooks[hookName]) == TYPE_FUNCTION then
        hooks[hookName](length - (string.len(hookName) + 1) * 8, ...)
    end
end)