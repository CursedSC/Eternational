net.WriteVars[TYPE_FUNCTION] = function (t, v) net.WriteUInt(t, 8) end
net.ReadVars[TYPE_FUNCTION] = function () return nil end

net.WriteVars[TYPE_PHYSOBJ] = function (t, v) net.WriteUInt(t, 8) net.WriteEntity(v:GetEntity()) end
net.ReadVars[TYPE_PHYSOBJ] = function () return net.ReadEntity():GetPhysicsObject() end