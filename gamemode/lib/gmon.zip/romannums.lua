local additionMap = {
    I = 1,
    X = 10,
    C = 100,
    M = 1000
}

local substractionMap = {
    V = 1,
    X = 1,
    L = 10,
    C = 10,
    D = 100,
    M = 100
}

local numeralsMap = {
    I = 1,
    V = 5,
    X = 10,
    L = 50,
    C = 100,
    D = 500,
    M = 1000
}

local romanNumsOrder = { { "I", "V", "X" }, { "X", "L", "C" }, { "C", "D", "M" }, { "M", "M", "M" } }

romannums = { }

function romannums.Encode(str)
    result = ""

    str = tostring(str)

    if str and type(str) == "string" and (string.len(str) <= 4) then
        local strLen = string.len(str)
        local revStr = string.reverse(str)

        for i=1, strLen do
            local letter = string.sub(revStr, i, i)

            local digit = string.byte(letter,1) - string.byte("0", 1)
            local orderRes = ""

            local symbolReps = 0
            local substSymbol = 1
            local substSymbolIncrement = 1
            local j=1

            while j <= digit do
                orderRes = orderRes .. romanNumsOrder[i][substSymbol]
                symbolReps = symbolReps + 1

                if symbolReps > 3 then
                    if i >= 4 then
                        orderRes = "MMM"

                        break
                    end

                    orderRes = romanNumsOrder[i][substSymbol]
                    substSymbol = substSymbol + substSymbolIncrement
                    orderRes = orderRes .. romanNumsOrder[i][substSymbol]
                    symbolReps = 0

                    if j + 1 <= digit then
                        orderRes = romanNumsOrder[i][substSymbol]

                            j = j + 1

                        substSymbol = substSymbol - substSymbolIncrement
                        substSymbolIncrement = substSymbolIncrement + 1
                    end
                end

                j = j + 1
            end

            substSymbolIncrement = 1

            result = string.format("%s%s", orderRes, result)
        end
    end

    return result
end

function romannums.Decode(str)
    local result = {}

    if str and type(str) == "string" then
        local strLen = string.len(str)
        local resultPos = 1

        for i=1, strLen do
            local letter = string.sub(str, i, i)

            if not result[resultPos] then
                table.insert(result, numeralsMap[letter])
            else
                if result[resultPos] == substractionMap[letter] then
                    result[resultPos] = numeralsMap[letter] - result[resultPos]
                    resultPos = resultPos + 1
                elseif result[resultPos] == additionMap[letter] then
                    result[resultPos] = result[resultPos] + numeralsMap[letter]
                else
                    resultPos = resultPos + 1

                    table.insert(result, numeralsMap[letter])
                end
            end
        end
    else
        print("roman2arabic: invalid input")
    end

    local arabicNum = 0

    for i, v in ipairs(result) do
        arabicNum = arabicNum + v
    end

    return arabicNum
end