danimation = { }

function danimation.Create(startValue, speed)
    return oop.NewInstance("DAnimation", startValue, speed)
end

function danimation.CreateManager()
    return oop.NewInstance("DAnimationManager")
end
