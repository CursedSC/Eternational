function hook.Once(eventName, identifier, callback)
    hook.Add(eventName, identifier, function(...)
        callback(...)

        hook.Remove(eventName, identifier)
    end)
end