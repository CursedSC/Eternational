if SERVER then
    util.AddNetworkString("netreq.request")
    util.AddNetworkString("netreq.response")
end

local requests = { }
local listeners = { }

local Request = { }
Request.__index = Request

function Request:new(name)
    local object = setmetatable({
        data = { },
        name = name,
        identifier = string.random(10),
        promise = Promise:new()
    }, Request)

    requests[object.identifier] = object

    return object
end

function Request:Write(name, value)
    if name == nil then
        return
    end

    self.data[name] = value

    return self
end

function Request:Sended()
    return not not self.sended
end

if SERVER then
    function Request:Send(clients)
        if self.sended then
            return
        end

        net.Start("netreq.request")

        net.WriteString(self.name)
        net.WriteString(self.identifier)
        net.WriteTable(self.data)

        if  TypeID(clients) == TYPE_TABLE or
            (TypeID(clients) == TYPE_ENTITY and clients:IsPlayer())
        then
            net.Send(clients)
        else
            net.Broadcast()
        end

        self.sended = true

        return requests[self.identifier].promise
    end
elseif CLIENT then
    function Request:Send()
        if self.sended then
            return
        end

        net.Start("netreq.request")

        net.WriteString(self.name)
        net.WriteString(self.identifier)
        net.WriteTable(self.data)

        net.SendToServer()

        self.sended = true

        return requests[self.identifier].promise
    end
end

local Response = { }
Response.__index = Response

function Response:new(name, identifier, sender)
    local object = setmetatable({
        data = { },
        name = name,
        identifier = identifier,
        sender = sender
    }, Response)

    return object
end

function Response:Write(name, value)
    if name == nil then
        return
    end

    self.data[name] = value

    return self
end

function Response:Sended()
    return not not self.sended
end

if SERVER then
    function Response:Send()
        if self.sended then
            return
        end

        net.Start("netreq.response")

        net.WriteString(self.identifier)
        net.WriteTable(self.data)

        net.Send(self.sender)

        self.sended = true
    end
elseif CLIENT then
    function Response:Send()
        if self.sended then
            return
        end

        net.Start("netreq.response")

        net.WriteString(self.identifier)
        net.WriteTable(self.data)

        net.SendToServer()

        self.sended = true
    end
end

netreq = { }

function netreq.Create(name)
    return Request:new(name)
end

function netreq.Listen(name, callback)
    if  TypeID(name) ~= TYPE_STRING or
        TypeID(callback) ~= TYPE_FUNCTION
    then
        return false
    end

    listeners[name] = callback

    return true
end

net.Receive("netreq.request", function(length, player)
    local name = net.ReadString()
    local identifier = net.ReadString()
    local data = net.ReadTable()

    if listeners[name] then
        local response = Response:new(name, identifier, player)

        listeners[name]({
            sender = player,
            data = data
        }, response)

        response:Send()
    end
end)

net.Receive("netreq.response", function(length, player)
    local identifier = net.ReadString()
    local data = net.ReadTable()

    if requests[identifier] then
        requests[identifier].promise:resolve({
            sender = player,
            data = data
        })
    end
end)