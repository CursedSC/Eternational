Promise = { }
Promise.__index = Promise

function Promise:new(callback)
    local object = setmetatable({
        state = "pending",
        resolves = { },
        rejects = { }
    }, Promise)

    if type(callback) == "function" then
        timer.Simple(0, function()
            local resolve = function(value)
                object:resolve(value)
            end

            local reject = function(reason)
                object:reject(reason)
            end

            callback(resolve, reject)
        end)
    end

    return object
end

function Promise:next(callback, failback)
    if type(callback) == "function" then
        table.insert(self.resolves, callback)
    end

    if type(failback) == "function" then
        table.insert(self.rejects, failback)
    end

    return self
end

function Promise:catch(failback)
    if type(failback) == "function" then
        self.onReject = failback
    end

    return self
end

function Promise:resolve(value)
    self.result = value

    if self.state == "pending" then
        self.state = "resolved"

        for index, resolveFunction in pairs(self.resolves) do
            value = resolveFunction(value)
        end
    end
end

function Promise:reject(reason)
    self.result = reason

    if self.state == "pending" then
        self.state = "rejected"

        for index, rejectFunction in pairs(self.rejects) do
            reason = rejectFunction(reason)
        end
    end
end