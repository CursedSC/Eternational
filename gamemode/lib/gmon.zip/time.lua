time = { }

time.DAWN = 0
time.DAY = 1
time.DUSK = 2
time.NIGHT = 3

time.settings = {
    offset = 0, -- Offset from current time in seconds
    rspgs = 24, -- Real seconds per the game second
    dawnStart = 5 * 3600, -- Dawn start time in seconds
    dayStart = 7 * 3600, -- Day start time in seconds
    duskStart = 20 * 3600, -- Dusk start time in seconds
    nightStart = 22 * 3600 -- Night start time in seconds
}

function time.GetTime(seconds)
    local time = TypeID(seconds) == TYPE_NUMBER and seconds or (CurTime() * time.settings.rspgs + time.settings.offset) % 86400

    local timeCopy = time

    local h = math.floor(timeCopy / 3600)

    timeCopy = timeCopy - h * 3600

    local m = math.floor(timeCopy / 60)

    timeCopy = timeCopy - m * 60

    local s = timeCopy

    return {
        total = time,
        h = h,
        m = m,
        s = s
    }
end

function time.GetFormatTime(seconds, format)
    if TypeID(format) ~= TYPE_STRING then
        format = "h:m:s"
    end

    local time = time.GetTime(seconds)

    local h, m, s = tostring(time.h), tostring(time.m), tostring(math.floor(time.s))

    if string.len(h) == 1 then
        h = "0" .. h
    end

    if string.len(m) == 1 then
        m = "0" .. m
    end

    if string.len(s) == 1 then
        s = "0" .. s
    end

    format = string.Replace(format, "h", h)
    format = string.Replace(format, "m", m)
    format = string.Replace(format, "s", s)

    return format
end

function time.TimesOfDay()
    local currentTime = time.GetTime().total

    if currentTime >= time.settings.dawnStart and currentTime < time.settings.dayStart then
        return time.DAWN
    elseif currentTime >= time.settings.dayStart and currentTime < time.settings.duskStart then
        return time.DAY
    elseif currentTime >= time.settings.duskStart and currentTime < time.settings.nightStart then
        return time.DUSK
    end

    return time.NIGHT
end

if SERVER then
    util.AddNetworkString("time.changeOffset")
    util.AddNetworkString("time.getOffset")

    function time.SetTime(newTime)
        time.settings.offset = newTime - CurTime() * time.settings.rspgs % 86400

        net.Start("time.changeOffset")
            net.WriteDouble(time.settings.offset)
        net.Broadcast()
    end

    local SKYPAINT ={
        [time.DAWN] = {
            TopColor        = Vector(0.2, 0.5, 1),
            BottomColor     = Vector(0.46, 0.65, 0.49),
            FadeBias        = 1,
            HDRScale        = 0.26,
            StarScale       = 1.84,
            StarFade        = 0,
            StarSpeed       = 0.02,
            DuskScale       = 1,
            DuskIntensity   = 1,
            DuskColor       = Vector(1, 0.2, 0),
            SunColor        = Vector(0.2, 0.1, 0),
            SunSize         = 2,
        },
        [time.DAY] = {
            TopColor        = Vector(0.2, 0.49, 1),
            BottomColor     = Vector(0.8, 1, 1),
            FadeBias        = 1,
            HDRScale        = 0.26,
            StarScale       = 1.84,
            StarFade        = 1.5,
            StarSpeed       = 0.02,
            DuskScale       = 1,
            DuskIntensity   = 1,
            DuskColor       = Vector(1, 0.2, 0),
            SunColor        = Vector(0.83, 0.45, 0.11),
            SunSize         = 0.34,
        },
        [time.DUSK] = {
            TopColor        = Vector(0.24, 0.15, 0.08),
            BottomColor     = Vector(0.4, 0.07, 0),
            FadeBias        = 1,
            HDRScale        = 0.36,
            StarScale       = 1.50,
            StarFade        = 5,
            StarSpeed       = 0.01,
            DuskScale       = 1,
            DuskIntensity   = 1.94,
            DuskColor       = Vector(0.69, 0.22, 0.02),
            SunColor        = Vector(0.90, 0.30, 0.00),
            SunSize         = 0.44,
        },
        [time.NIGHT] = {
            TopColor        = Vector(0.00, 0.00, 0.00),
            BottomColor     = Vector(0.05, 0.05, 0.11),
            FadeBias        = 0.1,
            HDRScale        = 0.19,
            StarScale       = 1.50,
            StarFade        = 5,
            StarSpeed       = 0.01,
            DuskScale       = 0,
            DuskIntensity   = 0,
            DuskColor       = Vector(1, 0.36, 0),
            SunColor        = Vector(0.83, 0.45, 0.11),
            SunSize         = 0,
        }
    }

    local envSkyPaint
    local envSun, envSunTurnOff

    hook.Add("Think", "time.skyControl", function()
        if  not IsValid(envSkyPaint) or
            not IsValid(envSun)
        then
            if not IsValid(envSkyPaint) then
                envSkyPaint = ents.FindByClass("env_skypaint")[1]

                if IsValid(envSkyPaint) then
                    envSkyPaint:SetStarTexture("skybox/starfield")
                end
            end

            if not IsValid(envSun) then
                envSun = ents.FindByClass("env_sun")[1]

                if IsValid(envSun) then
                    envSun:SetKeyValue("sun_dir", "1 0 0")
                end
            end

            return
        end

        local currentTime = time.GetTime().total

        local dawnMidTime = (time.settings.dawnStart + time.settings.dayStart) / 2
        local duskMidTime = (time.settings.duskStart + time.settings.nightStart) / 2

        local fromTimesOfDay = time.NIGHT
        local toTimesOfDay = time.NIGHT
        local fraction = 0

        if currentTime >= time.settings.dawnStart and currentTime < dawnMidTime then
            fromTimesOfDay = time.NIGHT
            toTimesOfDay = time.DAWN

            fraction = math.EaseInOut((currentTime - time.settings.dawnStart) / (dawnMidTime - time.settings.dawnStart), 0.3, 0.3)
        elseif currentTime >= dawnMidTime and currentTime < time.settings.dayStart then
            fromTimesOfDay = time.DAWN
            toTimesOfDay = time.DAY

            fraction = math.EaseInOut((currentTime - dawnMidTime) / (time.settings.dayStart - dawnMidTime), 0.3, 0.3)
        elseif currentTime >= time.settings.duskStart and currentTime < duskMidTime then
            fromTimesOfDay = time.DAY
            toTimesOfDay = time.DUSK

            fraction = math.EaseInOut((currentTime - time.settings.duskStart) / (duskMidTime - time.settings.duskStart), 0.3, 0.3)
        elseif currentTime >= duskMidTime and currentTime < time.settings.nightStart then
            fromTimesOfDay = time.DUSK
            toTimesOfDay = time.NIGHT

            fraction = math.EaseInOut((currentTime - duskMidTime) / (time.settings.nightStart - duskMidTime), 0.3, 0.3)
        elseif currentTime >= time.settings.dayStart and currentTime < time.settings.duskStart then
            fromTimesOfDay = time.DAY
            toTimesOfDay = time.DAY
        end

        envSkyPaint:SetTopColor(LerpVector(fraction, SKYPAINT[fromTimesOfDay].TopColor, SKYPAINT[toTimesOfDay].TopColor))
        envSkyPaint:SetBottomColor(LerpVector(fraction, SKYPAINT[fromTimesOfDay].BottomColor, SKYPAINT[toTimesOfDay].BottomColor))
        envSkyPaint:SetSunColor(LerpVector(fraction, SKYPAINT[fromTimesOfDay].SunColor, SKYPAINT[toTimesOfDay].SunColor))
        envSkyPaint:SetDuskColor(LerpVector(fraction, SKYPAINT[fromTimesOfDay].DuskColor, SKYPAINT[toTimesOfDay].DuskColor))
        envSkyPaint:SetFadeBias(Lerp(fraction, SKYPAINT[fromTimesOfDay].FadeBias, SKYPAINT[toTimesOfDay].FadeBias))
        envSkyPaint:SetHDRScale(Lerp(fraction, SKYPAINT[fromTimesOfDay].HDRScale, SKYPAINT[toTimesOfDay].HDRScale))
        envSkyPaint:SetDuskScale(Lerp(fraction, SKYPAINT[fromTimesOfDay].DuskScale, SKYPAINT[toTimesOfDay].DuskScale))
        envSkyPaint:SetDuskIntensity(Lerp(fraction, SKYPAINT[fromTimesOfDay].DuskIntensity, SKYPAINT[toTimesOfDay].DuskIntensity))
        envSkyPaint:SetSunSize(Lerp(fraction, SKYPAINT[fromTimesOfDay].SunSize, SKYPAINT[toTimesOfDay].SunSize))

        envSkyPaint:SetStarFade(SKYPAINT[toTimesOfDay].StarFade)
        envSkyPaint:SetStarScale(SKYPAINT[toTimesOfDay].StarScale)
        envSkyPaint:SetStarSpeed(SKYPAINT[toTimesOfDay].StarSpeed)

        if fromTimesOfDay == time.NIGHT then
            if not envSunTurnOff then
                envSun:Fire("TurnOff", "", 0)

                envSunTurnOff = true
            end
        else
            if envSunTurnOff then
                envSun:Fire("TurnOn", "", 0)

                envSunTurnOff = false
            end
        end

        local sunAngle = Angle(0, 15, 0)

        if currentTime >= time.settings.dawnStart and currentTime <= time.settings.nightStart then
            sunAngle = Angle(-180 * (1 - (currentTime - time.settings.dawnStart) / (time.settings.nightStart - time.settings.dawnStart)), 15, 0)
        else
            -- local nightLength = 24 * 60 * 60 - time.settings.nightStart + time.settings.dawnStart
            -- local nightTime

            -- if currentTime > time.settings.nightStart then
            --     nightTime = currentTime - time.settings.nightStart
            -- else
            --     nightTime = 24 * 60 * 60 - time.settings.nightStart + currentTime
            -- end

            -- sunAngle = Angle(-180 * (1 - nightTime / nightLength), 15, 0)
        end

        envSun:SetKeyValue("sun_dir", tostring(sunAngle:Forward()))

        envSkyPaint:SetSunNormal(envSun:GetInternalVariable("m_vDirection"))
    end)

    net.Receive("time.getOffset", function(length, player)
        net.Start("time.changeOffset")
            net.WriteDouble(time.settings.offset)
        net.Send(player)
    end)

    if player.GetCount() > 0 then
        net.Start("time.changeOffset")
            net.WriteDouble(time.settings.offset)
        net.Broadcast()
    end
else
    net.Receive("time.changeOffset", function(length, player)
        time.settings.offset = net.ReadDouble()

        if timer.Exists("time.initOffset") then
            timer.Remove("time.initOffset")
        end
    end)

    timer.Create("time.initOffset", 0.5, 0, function()
        net.Start("time.getOffset")
        net.SendToServer()
    end)
end
