if SERVER then
    return
end

local canvasW, canvasH

local function draw4angles(p1, p2, p3, p4, color)
    color = color or Color(255, 255, 255)
    surface.SetDrawColor(color.r, color.g, color.b, color.a)
    surface.DrawPoly({ p1, p2, p3 })
    surface.DrawPoly({ p3, p4, p1 })
end

Vector2 = function(x, y)
    return { x = x, y = y or x }
end

ui3d = { }

ui3d.SetCanvasSize = function(w, h)
    canvasW = w
    canvasH = h
end

ui3d.V3ToV2 = function(v3)
    local w, h = canvasW or ScrW(), canvasH or ScrH()
    local wh = w > h and w or h

    return {
        x = v3.x / v3.z * wh / 2 + w / 2,
        y = v3.y / v3.z * wh / 2 + h / 2
    }
end

ui3d.RotateV3 = function(v3, ang)
    local copyV3 = Vector(v3.x, v3.y, v3.z)

    copyV3:Rotate(ang)

    return copyV3

    --[[
    local xr, yr, zr = math.rad(ang.pitch), math.rad(ang.yaw), math.rad(ang.roll)
    local cos_x, sin_x = math.cos(xr), math.sin(xr)
    local cos_y, sin_y = math.cos(yr), math.sin(yr)
    local cos_z, sin_z = math.cos(zr), math.sin(zr)

    local m11 = cos_x * cos_z - sin_x * cos_y * sin_z
    local m12 = -cos_y * sin_z - sin_x * cos_y * cos_z
    local m13 = sin_x * sin_y

    local m21 = sin_x * cos_z + cos_x * cos_y * sin_z
    local m22 = -sin_x * sin_z + cos_x * cos_y * cos_z
    local m23 = -cos_x * sin_y

    local m31 = sin_y * sin_z
    local m32 = sin_y * cos_z
    local m33 = cos_y

    return Vector(
        m11 * v3.x + m12 * v3.y + m13 * v3.z,
        m21 * v3.x + m22 * v3.y + m23 * v3.z,
        m31 * v3.x + m32 * v3.y + m33 * v3.z
    )
    ]]
end

ui3d.drawPlace = function(pos, ang, size, color)
    color = color or Color(255, 255, 255)
    size = table.Copy(size)
    size.x, size.y = size.x / 2, size.y / 2

    local p1 = ui3d.V3ToV2(ui3d.RotateV3(Vector(size.x, size.y, 0), ang) + pos)
    local p2 = ui3d.V3ToV2(ui3d.RotateV3(Vector(-size.x, size.y, 0), ang) + pos)
    local p3 = ui3d.V3ToV2(ui3d.RotateV3(Vector(-size.x, -size.y, 0), ang) + pos)
    local p4 = ui3d.V3ToV2(ui3d.RotateV3(Vector(size.x, -size.y, 0), ang) + pos)

    draw4angles(p1, p2, p3, p4, color)
end

ui3d.drawSprite = function(pos, ang, size, mat, color)
    color = color or Color(255, 255, 255)
    size = table.Copy(size)
    size.x, size.y = size.x / 2, size.y / 2

    local p1 = ui3d.V3ToV2(ui3d.RotateV3(Vector(size.x, size.y, 0), ang) + pos)
    local p2 = ui3d.V3ToV2(ui3d.RotateV3(Vector(-size.x, size.y, 0), ang) + pos)
    local p3 = ui3d.V3ToV2(ui3d.RotateV3(Vector(-size.x, -size.y, 0), ang) + pos)
    local p4 = ui3d.V3ToV2(ui3d.RotateV3(Vector(size.x, -size.y, 0), ang) + pos)

    surface.SetDrawColor(color.r, color.g, color.b, color.a)
    surface.SetMaterial(mat)
    surface.DrawPoly({
        { x = p1.x, y = p1.y, u = 0, v = 1 },
        { x = p2.x, y = p2.y, u = 0, v = 0 },
        { x = p3.x, y = p3.y, u = 1, v = 0 },
        { x = p4.x, y = p4.y, u = 1, v = 1 }
    })
end