
PMETA = FindMetaTable("Player")
EMETA = FindMetaTable("Entity")

function EMETA:IsConsole()
    if self:EntIndex() == 0 then return true end

    return false
end

function EMETA:GetDistance(ent)
    return self:GetPos():DistToSqr(ent:GetPos())
end