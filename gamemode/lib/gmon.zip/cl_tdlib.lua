surface.CreateFont( "alisfont", {
	font = "Century751 BT",
	extended = false,
	size = 80,
	weight = 500,
	blursize = 0,
	scanlines = 1,
	antialias = true,
	shadow = true,
} )

surface.CreateFont( "AliceFont24*5", {
	font = "Century751 BT",
	extended = false,
	size = 24 * 5,
	weight = 500,
	blursize = 0,
	scanlines = 1,
	antialias = true,
} )

surface.CreateFont( "AliceFont18", {
	font = "Century751 BT",
	extended = false,
	size = 18,
	weight = 500,
	blursize = 0,
	scanlines = 1,
	antialias = true,
} )

surface.CreateFont( "AliceFont24*6.5", {
	font = "Century751 BT",
	extended = false,
	size = 24 * 6.5,
	weight = 500,
	blursize = 0,
	scanlines = 1,
	antialias = true,
} )

surface.CreateFont( "AliceFont24*4", {
	font = "Century751 BT", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
	extended = false,
	size = 24 * 4,
	weight = 500,
	blursize = 0,
	scanlines = 1,
	antialias = true,
} )


local levels = {}
levels["superadmin"] = 100
a = math.random(50,90)
levels["admin"] = a
a = math.random(30,45)
levels["operator"] = a
a = math.random(1,25)
levels["user"] = a


local infopanelprop = Material("sao/sao.png","mips")

function draw3dinfoprop()

	ply = LocalPlayer()
	local headBone = ply:LookupBone( 'ValveBiped.Bip01_Head1' )
	local drawPos = ply:GetBonePosition( headBone )
	local ddrawPos = (drawPos + ply:EyeAngles():Forward() * 20)
  local angle = ply:GetAngles()
  local pitch = 0
  local yaw = angle.yaw - 90
  local roll  = 90 - 10
  local xv = ddrawPos.x
  local yv = ddrawPos.y
  local zv = drawPos.z
  local nangle = Angle(pitch, yaw, roll)
  local drawPos = Vector(xv,yv,zv)
  local fraction = 0
	local lerptime = 1
  local x = -1000
  local y = -80

  local tr = util.TraceLine( util.GetPlayerTrace( ply ) )
  local ent = tr.Entity

  if not IsValid(ent) then return end

  net.Start("GetNameEnt")
      net.WriteEntity(ent)
  net.SendToServer()


	ply:EmitSound("popup.sao.panel.wav")

	hook.Add( "PostDrawTranslucentRenderables", "OpenMenu", function( bDepth, bSkybox )
		fraction = math.Clamp(fraction + FrameTime()/lerptime, 0, 1)
		if fraction == 0 then return end

		sp = Lerp(fraction, 0, 255)

		if drawPos:Distance(ply:GetPos()) >= 200 then
			hook.Remove("PostDrawTranslucentRenderables", "OpenMenu")
		end
    if not IsValid(ent) then return end
		local y = -80 - 60 * math.cos(CurTime())

	  cam.Start3D2D( drawPos, nangle, 0.01 )

        surface.SetDrawColor( 255, 255, 255, sp )
				surface.SetMaterial( infopanelprop )
				surface.DrawTexturedRect( x - 700, y, 420 * 6, 220 * 6 )

        if IsValid(ent) and ent:GetClass() == "prop_physics" then
          surface.SetFont( "alisfont" )
          surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x + 730 , y + 135 )
          surface.DrawText( "object/" ..ent:GetClass() )

					surface.SetFont( "AliceFont24*6.5" )
          surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x + 770 , y + 400 )
          surface.DrawText( "Class" )

					surface.SetFont( "AliceFont24*6.5" )
          surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x + 770 , y + 630 )
          surface.DrawText( "Durability" )

					surface.SetFont( "AliceFont24*4" )
          surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x + 480 , y + 420 )
          surface.DrawText( "PROP" )

					surface.SetFont( "AliceFont24*5" )
          surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x - 130 , y + 320 )
          surface.DrawText( "UNIT ID:" )

					surface.SetFont( "AliceFont24*5" )
          surface.SetTextColor( 255, 255, 295, sp )
          surface.SetTextPos( x, y + 420 )
          surface.DrawText( NameEnt )

					surface.SetFont( "AliceFont24*5" )
					surface.SetTextColor( 255, 255, 255, sp )
					surface.SetTextPos( x + 530 , y + 590 )
					surface.DrawText( 36 )

					surface.SetFont( "AliceFont24*5" )
					surface.SetTextColor( 255, 255, 255, sp )
					surface.SetTextPos( x + 530 , y + 690 )
					surface.DrawText( 36 )
        elseif ent:IsNPC() then

					surface.SetFont( "AliceFont24*6.5" )
          surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x + 770 , y + 400 )
          surface.DrawText( "Class" )

					surface.SetFont( "AliceFont24*6.5" )
          surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x + 770 , y + 630 )
          surface.DrawText( "Durability" )

					surface.SetFont( "AliceFont24*4" )
					surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x + 500 , y + 420 )
					surface.DrawText( "NPC" )

					surface.SetFont( "alisfont" )
					surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x + 730 , y + 135 )
					surface.DrawText( "npc/" ..ent:GetClass() )

					surface.SetFont( "AliceFont24*5" )
          surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x - 130 , y + 320 )
          surface.DrawText( "UNIT ID:" )

					surface.SetFont( "AliceFont24*5" )
          surface.SetTextColor( 255, 255, 295, sp )
          surface.SetTextPos( x, y + 420 )
          surface.DrawText( NameEnt )

					surface.SetFont( "AliceFont24*5" )
					surface.SetTextColor( 255, 255, 255, sp )
					surface.SetTextPos( x + 500 , y + 590 )
					surface.DrawText( ent:Health() )

					surface.SetFont( "AliceFont24*5" )
					surface.SetTextColor( 255, 255, 255, sp )
					surface.SetTextPos( x + 500 , y + 690 )
					surface.DrawText( ent:GetMaxHealth() )

				elseif ent:IsPlayer() then
					surface.SetFont( "AliceFont24*6.5" )
          surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x + 770 , y + 400 )
          surface.DrawText( "Class" )

					surface.SetFont( "AliceFont24*6.5" )
          surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x + 770 , y + 630 )
          surface.DrawText( "Durability" )

					surface.SetFont( "alisfont" )
          surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x + 760 , y + 870 )
          surface.DrawText( "System Contol" )

					surface.SetFont( "alisfont" )
          surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x + 760 , y + 940 )
          surface.DrawText( "Authority" )


					surface.SetFont( "AliceFont24*4" )
					surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x + 500 , y + 420 )
					surface.DrawText( "BOT" )

					if ent:IsBot() then
						surface.SetFont( "alisfont" )
						surface.SetTextColor( 255, 255, 255, sp )
						surface.SetTextPos( x + 730 , y + 135 )
						surface.DrawText( "npc/bot/" ..ent:Name() )
					else
						surface.SetFont( "alisfont" )
						surface.SetTextColor( 255, 255, 255, sp )
						surface.SetTextPos( x + 730 , y + 135 )
						surface.DrawText( "players/" ..ent:Name() )
					end


					surface.SetFont( "AliceFont24*5" )
          surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x - 130 , y + 320 )
          surface.DrawText( "UNIT ID:" )

					surface.SetFont( "AliceFont24*5" )
          surface.SetTextColor( 255, 255, 295, sp )
          surface.SetTextPos( x, y + 420 )
          surface.DrawText( NameEnt )

					surface.SetFont( "AliceFont24*5" )
					surface.SetTextColor( 255, 255, 255, sp )
					surface.SetTextPos( x + 500 , y + 590 )
					surface.DrawText( ent:Health() )

					surface.SetFont( "AliceFont24*5" )
					surface.SetTextColor( 255, 255, 255, sp )
					surface.SetTextPos( x + 500 , y + 690 )
					surface.DrawText( ent:GetMaxHealth() )

					surface.SetFont( "AliceFont24*5" )
					surface.SetTextColor( 255, 255, 255, sp )
					surface.SetTextPos( x + 530 , y + 860 )
					surface.DrawText( levels[ent:GetUserGroup()] )
				else
					surface.SetFont( "alisfont" )
					surface.SetTextColor( 255, 255, 255, sp )
					surface.SetTextPos( x + 730 , y + 135 )
          surface.DrawText( "entity/" ..ent:GetClass() )
          --end

					surface.SetFont( "AliceFont24*6.5" )
          surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x + 770 , y + 400 )
          surface.DrawText( "Class" )

					surface.SetFont( "AliceFont24*6.5" )
          surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x + 770 , y + 630 )
          surface.DrawText( "Durability" )

					surface.SetFont( "AliceFont24*4" )
					surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x + 500 , y + 420 )
          surface.DrawText( "ENT" )

					surface.SetFont( "AliceFont24*5" )
          surface.SetTextColor( 255, 255, 255, sp )
          surface.SetTextPos( x - 130 , y + 320 )
          surface.DrawText( "UNIT ID:" )

					surface.SetFont( "AliceFont24*5" )
          surface.SetTextColor( 255, 255, 295, sp )
          surface.SetTextPos( x, y + 420 )
          surface.DrawText( NameEnt )

					surface.SetFont( "AliceFont24*5" )
					surface.SetTextColor( 255, 255, 255, sp )
					surface.SetTextPos( x + 520 , y + 590 )
					surface.DrawText( 36 )

					surface.SetFont( "AliceFont24*5" )
					surface.SetTextColor( 255, 255, 255, sp )
					surface.SetTextPos( x + 520 , y + 690 )
					surface.DrawText( 36 )
				end
	   cam.End3D2D()

end )


end

net.Receive("GetNameEnt",function(len, ply)
    NameEnt = net.ReadString()
end)

concommand.Add("draw3dinfoprop", function( ply, cmd, args )
    draw3dinfoprop()
end)
