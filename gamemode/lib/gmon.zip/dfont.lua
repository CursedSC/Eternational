if SERVER then
    return
end

local fonts = { }
local wscr, hscr = ScrW(), ScrH()

local function EvalTable(table)
    local result = { }
    local key = nil

    repeat
        key = next(table, key)
        if key == nil then break end

        if TypeID(table[key]) == TYPE_FUNCTION then
            result[key] = table[key]()
        elseif TypeID(table[key]) == TYPE_TABLE then
            result[key] = EvalTable(table[key])
        else
            result[key] = table[key]
        end

    until false

    return result
end

dfont = dfont or { }

function dfont.Create(fontName, fontData)
    fonts[fontName] = fontData

    surface.CreateFont(fontName, EvalTable(fontData))
end

function dfont.Destroy(fontName)
    fonts[fontName] = nil
end

function dfont.IsExists(fontName)
    return fonts[fontName] ~= nil
end

hook.Add("Think", "dfont.checkSizeScreen", function()
    local nWscr, nHscr = ScrW(), ScrH()

    if wscr ~= nWscr or hscr ~= nHscr then
        wscr, hscr = nWscr, nHscr

        local fontName

        repeat
            fontName = next(fonts, fontName)
            if fontName == nil then break end

            local fontData = fonts[fontName]

            surface.CreateFont(fontName, EvalTable(fontData))
        until false
    end
end)
