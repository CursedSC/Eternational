vector = { }

function vector.Create(...)
    local arguments = { ... }
    local argumentsCount = #arguments

    if argumentsCount == 2 then
        return {
            x = arguments[1],
            y = arguments[2]
        }
    elseif argumentsCount == 3 then
        return Vector(arguments[1], arguments[2], arguments[3])
    elseif argumentsCount == 4 then
        return Vector(arguments[1], arguments[2], arguments[3], arguments[4])
    end
end