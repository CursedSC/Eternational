teleport = { }

function teleport.IsPointFree(point, players, exceptions)
    players = TypeID(players) == TYPE_TABLE and players or player.GetAll()
    
    local playersCount = #players

    if TypeID(exceptions) == TYPE_TABLE then
        local exceptionsCount = #exceptions

        for exceptionIndex = 1, exceptionsCount do
            local exception = exceptions[exceptionIndex]

            table.RemoveByValue(players, exception)
        end
    elseif TypeID(exceptions) == TYPE_ENTITY and exceptions:IsPlayer() then
        table.RemoveByValue(players, exceptions)
    end

    for playerIndex = 1, playersCount do
        local player = players[playerIndex]

        if player == nil then
            continue
        end

        if player:GetPos():DistToSqr(point) < 250 then
            return false
        end
    end

    return true
end

if SERVER then
    local playerGetAll = player.GetAll

    local teleportTypes = {
        ["circle"] = function(player, positionData)
            local players = playerGetAll()
            local playersCount = #players

            local mapPlayers = { }

            for playerIndex = 1, playersCount do
                local currentPlayer = players[playerIndex]

                if player == currentPlayer then
                    continue
                end

                local currentPlayerPosition = currentPlayer:GetPos()

                local localCurrentPlayerPosition = currentPlayerPosition - positionData.position

                if  math.abs(localCurrentPlayerPosition.z) > 100 or
                    localCurrentPlayerPosition.x * localCurrentPlayerPosition.x + localCurrentPlayerPosition.y * localCurrentPlayerPosition.y > (position.maxRadius + 25) * (position.maxRadius + 25)
                then
                    continue
                end

                table.insert(mapPlayers, currentPlayer)
            end

            players = mapPlayers
            playersCount = #players

            for y = -positionData.maxRadius, positionData.maxRadius, 25 do
                for x = -positionData.maxRadius, positionData.maxRadius, 25 do
                    if x * x + y * y > positionData.maxRadius * positionData.maxRadius then
                        continue
                    end

                    local freePoint = true

                    for playerIndex = 1, playersCount do
                        local currentPlayer = players[playerIndex]

                        local currentPlayerPosition = currentPlayer:GetPos()

                        local localCurrentPlayerPosition = currentPlayerPosition - positionData.position

                        if math.pow(localCurrentPlayerPosition.x - x, 2) + math.pow(localCurrentPlayerPosition.y - y, 2) <= 2500 then
                            freePoint = false

                            break
                        end
                    end

                    if freePoint then
                        player:SetPos(Vector(positionData.position.x + x, positionData.position.y + y, positionData.position.z))
                    
                        return true
                    end
                end
            end

            return false
        end,

        ["square"] = function(player, positionData)
            local minPosition = Vector(
                positionData.min.x > positionData.max.x and positionData.max.x or positionData.min.x,
                positionData.min.y > positionData.max.y and positionData.max.y or positionData.min.y,
                0)

            local maxPosition = Vector(
                positionData.max.x > positionData.min.x and positionData.max.x or positionData.min.x,
                positionData.max.y > positionData.min.y and positionData.max.y or positionData.min.y,
                0)

            local players = playerGetAll()
            local playersCount = #players

            local mapPlayers = { }

            for playerIndex = 1, playersCount do
                local currentPlayer = players[playerIndex]

                if player == currentPlayer then
                    continue
                end

                local currentPlayerPosition = currentPlayer:GetPos()

                local localCurrentPlayerPosition = currentPlayerPosition - positionData.position

                if  currentPlayerPosition.z - 100 > positionData.position.z or
                    currentPlayerPosition.z + 100 < positionData.position.z or
                    localCurrentPlayerPosition.x - 25 > maxPosition.x or
                    localCurrentPlayerPosition.x + 25 < minPosition.x or
                    localCurrentPlayerPosition.y - 25 > maxPosition.y or
                    localCurrentPlayerPosition.y + 25 < minPosition.y
                then
                    continue
                end

                table.insert(mapPlayers, currentPlayer)
            end

            players = mapPlayers
            playersCount = #players

            for y = minPosition.y, maxPosition.y, 25 do
                for x = minPosition.x, maxPosition.x, 25 do
                    local freePoint = true

                    for playerIndex = 1, playersCount do
                        local currentPlayer = players[playerIndex]

                        local currentPlayerPosition = currentPlayer:GetPos()

                        local localCurrentPlayerPosition = currentPlayerPosition - positionData.position

                        if math.pow(localCurrentPlayerPosition.x - x, 2) + math.pow(localCurrentPlayerPosition.y - y, 2) <= 2500 then
                            freePoint = false

                            break
                        end
                    end

                    if freePoint then
                        player:SetPos(Vector(positionData.position.x + x, positionData.position.y + y, positionData.position.z))

                        return true
                    end
                end
            end

            return false
        end,

        ["points"] = function(player, positionData)
            local positions = positionData.positions
            local positionsCount = #positions

            local freePositions = { }

            for positionIndex = 1, positionsCount do
                local position = positions[positionIndex]

                if teleport.IsPointFree(position, nil, player) then
                    table.insert(freePositions, position)
                end
            end

            if #freePositions == 0 then
                return false
            end

            local randomFreePosition = table.Random(freePositions)

            player:SetPos(randomFreePosition)

            return true
        end,

        ["point"] = function(player, positionData)
            local position = positionData.position

            if TypeID(position) ~= TYPE_VECTOR and teleport.IsPointFree(position, nil, player) then
                return false
            end

            player:SetPos(position)

            return true
        end
    }

    function teleport.TeleportTo(player, positionData, ignorePointFree)
        if not positionData then
            return
        end

        if player:InVehicle() then
            player:ExitVehicle()
        end

        if spectator.IsSpectator(player) then
            spectator.UnSpectate(player)
        end

        if TypeID(positionData) == TYPE_VECTOR then
            if not ignorePointFree and not teleport.IsPointFree(positionData) then
                return false
            end

            player:SetPos(positionData + VectorRand(-1, 1))

            return true
        end

        local typePosition = positionData.type

        return teleportTypes[typePosition](player, positionData)
    end
end