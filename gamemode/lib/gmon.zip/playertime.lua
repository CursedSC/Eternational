playertime = { }

if SERVER then

    hook.Add("Think", "playertime.updatePlayerTime", function()

    end)

    hook.Add("PlayerSpawn", "playertime.initPlayer", function(player)

    end)


end

