function timer.CreateRandom(delay, repetitions, func)
    ::ReIdentify::

    local timerIdentifier = "randomTimer." .. math.Rand(0, 999999)

    if timer.Exists(timerIdentifier) then
        goto ReIdentify
    end

    timer.Create(timerIdentifier, delay, repetitions, func)

    return timerIdentifier
end